1. Tools -> Run Simulation Tools -> RTL Simulation
2. Stop the current execution, Restart
3. Click Processes Pane, Go to Objects Pane and Add PC_FE and pcplus_FE to Wave
4. Right Click the PC_FE, and pcplus_FE at Wave Pane, Change format to Hex
5. Start simulation, you will be able to see PC value. It starts from 0x100 by default. It may not increment because the frame is not complete yet. 