

ncvlog "D:/cs3220-4e0c52717f54de01f06e8f194a2b17e1e2d154ba/cs3220-4e0c52717f54de01f06e8f194a2b17e1e2d154ba/project3/Pll_sim/Pll.vo"
